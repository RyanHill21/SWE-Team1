import { Router } from 'express';
import mongoose from 'mongoose';
import Analytics from '../models/Analytics.js';

const router = Router();

router.get('/summary', async (req, res) => {
  try {
    const { userId } = req.query;
    if (!userId || !mongoose.isValidObjectId(userId)) {
      return res.status(400).json({ error: 'Valid userId is required' });
    }

    const doc = await Analytics.findOne({ userId }).lean();
    if (!doc) return res.json({ userId, totalStudyMinutes: 0, completionRate: 0, productivityScore: 0 });

    res.json({
      userId,
      totalStudyMinutes: doc.totalStudyMinutes,
      completionRate: doc.completionRate,
      productivityScore: doc.productivityScore,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/series', async (req, res) => {
  try {
    const { userId } = req.query;
    const range = parseInt(req.query.range || '14', 10);
    if (!userId || !mongoose.isValidObjectId(userId)) {
      return res.status(400).json({ error: 'Valid userId is required' });
    }

    const pipeline = [
      { $match: { userId: new mongoose.Types.ObjectId(userId) } },
      { $unwind: { path: '$byDay', preserveNullAndEmptyArrays: true } },
      { $sort: { 'byDay.date': 1 } },
      { $project: { _id: 0, date: '$byDay.date', studyMinutes: '$byDay.studyMinutes', completedTasks: '$byDay.completedTasks' } },
      { $limit: range }
    ];
    const rows = await Analytics.aggregate(pipeline);
    res.json({ userId, range, data: rows });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export default router;
